/**
 * Main class that inicializes the app
 * @author Luis Felipe
 * @author Mateus Assalti
 * @author Lucca Rolvare
 */
public class App{

  public static void main(String agrs[]){
    Window win = new Window();
  }
}
