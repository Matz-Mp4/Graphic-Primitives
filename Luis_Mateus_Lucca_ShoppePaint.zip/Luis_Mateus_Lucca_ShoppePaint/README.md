### Graphics Primitives

**Integrantes:** Lucca Rolvare de Oliveira Silva (RA00297921) | Luis Felipe Almeida Beserra Matos (RA00303863) | Mateus Assalti Santana (RA00301457) 
**Data:** 09/08/2022 08:01